<?php
// backend/index.php - PHP API for School Occurrences Portal

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/vendor/autoload.php';

use \Firebase\JWT\JWT;
use \Firebase\JWT\Key;

define('DB_FILE', __DIR__ . '/db.sqlite3');
define('SECRET_KEY', 'supersecretkey_php_change_me'); // Change in production!
define('ALGO', 'HS256');

function getDb() {
    $db = new PDO('sqlite:' . DB_FILE);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->exec('CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE,
        senha_hash TEXT NOT NULL,
        disciplina TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )');
    $db->exec('CREATE TABLE IF NOT EXISTS ocorrencias (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        aluno TEXT NOT NULL,
        turma TEXT NOT NULL,
        data TEXT NOT NULL,
        motivo TEXT NOT NULL,
        nomePai TEXT,
        nomeMae TEXT,
        estado TEXT,
        cidade TEXT,
        cep TEXT,
        bairro TEXT,
        telefone TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )');
    return $db;
}

function getBearerToken() {
    $headers = function_exists('apache_request_headers') ? apache_request_headers() : [];
    if (!empty($headers['Authorization'])) {
        if (preg_match('/Bearer\s(\S+)/', $headers['Authorization'], $matches)) {
            return $matches[1];
        }
    }
    if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
        if (preg_match('/Bearer\s(\S+)/', $_SERVER['HTTP_AUTHORIZATION'], $matches)) {
            return $matches[1];
        }
    }
    return null;
}

function sendResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    echo json_encode($data);
    exit;
}

function authenticate() {
    $token = getBearerToken();
    if (!$token) {
        sendResponse(['message' => 'Token missing'], 401);
    }
    try {
        $decoded = JWT::decode($token, new Key(SECRET_KEY, ALGO));
        return $decoded;
    } catch (Exception $e) {
        sendResponse(['message' => 'Invalid token: ' . $e->getMessage()], 403);
    }
}

// Routing logic begins
$method = $_SERVER['REQUEST_METHOD'];
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$base = dirname($_SERVER['SCRIPT_NAME']);
$path = substr($uri, strlen($base));
$path = rtrim($path, '/');

try {
    $db = getDb();

    if ($path === '/api/register' && $method === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        if (!isset($input['nome']) || !isset($input['senha'])) {
            sendResponse(['message' => 'Missing required fields: nome and senha'], 400);
        }
        $nome = trim($input['nome']);
        $email = isset($input['email']) ? trim($input['email']) : null;
        $senha = $input['senha'];
        $disciplina = isset($input['disciplina']) ? trim($input['disciplina']) : null;

        $senha_hash = password_hash($senha, PASSWORD_DEFAULT);

        $stmt = $db->prepare('INSERT INTO users (nome, email, senha_hash, disciplina) VALUES (?, ?, ?, ?)');
        try {
            $stmt->execute([$nome, $email, $senha_hash, $disciplina]);
            sendResponse(['message' => 'User registered'], 201);
        } catch (PDOException $e) {
            sendResponse(['message' => 'User already exists or error: ' . $e->getMessage()], 400);
        }
    } 

    else if ($path === '/api/login' && $method === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        if (!isset($input['nome']) || !isset($input['senha'])) {
            sendResponse(['message' => 'Missing credentials'], 400);
        }
        $nome = trim($input['nome']);
        $senha = $input['senha'];

        $stmt = $db->prepare('SELECT * FROM users WHERE nome = ?');
        $stmt->execute([$nome]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$user || !password_verify($senha, $user['senha_hash'])) {
            sendResponse(['message' => 'Invalid username or password'], 401);
        }

        $payload = [
            'iat' => time(),
            'exp' => time() + 7200, // 2 hours
            'sub' => $user['id'],
            'nome' => $user['nome'],
            'email' => $user['email']
        ];

        $jwt = JWT::encode($payload, SECRET_KEY, ALGO);
        sendResponse(['token' => $jwt, 'nome' => $user['nome']]);
    }

    else if ($path === '/api/ocorrencias') {
        $decoded = authenticate();

        if ($method === 'GET') {
            $stmt = $db->query('SELECT * FROM ocorrencias ORDER BY data DESC, created_at DESC');
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            sendResponse($rows);
        }
        else if ($method === 'POST') {
            $input = json_decode(file_get_contents('php://input'), true);

            $required = ['aluno', 'turma', 'data', 'motivo'];
            foreach ($required as $field) {
                if (empty($input[$field])) {
                    sendResponse(['message' => "Field $field is required"], 400);
                }
            }
            $stmt = $db->prepare('INSERT INTO ocorrencias 
                (aluno, turma, data, motivo, nomePai, nomeMae, estado, cidade, cep, bairro, telefone) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $stmt->execute([
                $input['aluno'],
                $input['turma'],
                $input['data'],
                $input['motivo'],
                $input['nomePai'] ?? null,
                $input['nomeMae'] ?? null,
                $input['estado'] ?? null,
                $input['cidade'] ?? null,
                $input['cep'] ?? null,
                $input['bairro'] ?? null,
                $input['telefone'] ?? null
            ]);
            sendResponse(['message' => 'Ocorrência adicionada'], 201);
        }
        else {
            sendResponse(['message' => 'Method not allowed'], 405);
        }
    }

    else {
        sendResponse(['message' => 'Not Found'], 404);
    }
} catch (Exception $e) {
    sendResponse(['message' => 'Server error: ' . $e->getMessage()], 500);
}
?>
