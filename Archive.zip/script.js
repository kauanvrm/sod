const API_BASE_URL = 'backend';

// Static data (can be moved server side in future)
const turmas = ["3ºA", "3ºB", "3ºC"];
const alunos = [
    { nome: "João Silva", turma: "3ºA" },
    { nome: "Maria Santos", turma: "3ºA" },
    { nome: "Carlos Oliveira", turma: "3ºB" },
    { nome: "Ana Souza", turma: "3ºB" },
    { nome: "Pedro Costa", turma: "3ºC" }
];

let token = null;
let ocorrencias = [];

const nomeUsuarioSpan = document.getElementById("nomeUsuario");
const btnLogin = document.getElementById("btnLogin");
const btnLogout = document.getElementById("btnLogout");

function saveToken(t) {
    token = t;
    localStorage.setItem('authToken', t);
}
function loadToken() {
    token = localStorage.getItem('authToken');
}
function clearToken() {
    token = null;
    localStorage.removeItem('authToken');
}

function atualizarUIUsuarioLogado() {
    loadToken();
    if (token) {
        try {
            const payload = JSON.parse(atob(token.split('.')[1]));
            nomeUsuarioSpan.textContent = payload.nome || "Usuário";
        } catch {
            nomeUsuarioSpan.textContent = "Usuário";
        }
        btnLogin.style.display = 'none';
        btnLogout.style.display = 'inline-block';
    } else {
        nomeUsuarioSpan.textContent = "Faça login";
        btnLogin.style.display = 'inline-block';
        btnLogout.style.display = 'none';
    }
}

function carregarTurmasPagina() {
    const listaTurmas = document.getElementById("listaTurmas");
    listaTurmas.innerHTML = "";
    turmas.forEach(turma => {
        const div = document.createElement("div");
        div.textContent = turma;
        listaTurmas.appendChild(div);
    });
}

document.addEventListener("DOMContentLoaded", () => {
    carregarTurmasPagina();
    atualizarUIUsuarioLogado();
    if (token) carregarOcorrenciasAPI();
});

function abrirFormulario() {
    document.getElementById("modalFormulario").style.display = "flex";
    carregarTurmasSelect();
}

function fecharFormulario() {
    document.getElementById("modalFormulario").style.display = "none";
    document.getElementById("formOcorrencia").reset();
    document.getElementById("alunosLista").style.display = "none";
    document.getElementById("alunosLista").innerHTML = "";
}

function carregarTurmasSelect() {
    const select = document.getElementById("turmaSelect");
    select.innerHTML = '<option value="">Selecione uma turma</option>';
    turmas.forEach(turma => {
        const option = document.createElement("option");
        option.value = turma;
        option.textContent = turma;
        select.appendChild(option);
    });
}

function carregarAlunos() {
    const turma = document.getElementById("turmaSelect").value;
    const alunosLista = document.getElementById("alunosLista");
    alunosLista.innerHTML = "";
    if (turma) {
        alunos.filter(aluno => aluno.turma === turma).forEach(aluno => {
            const div = document.createElement("div");
            div.className = "aluno-item";
            div.textContent = aluno.nome;
            div.onclick = () => preencherDadosAluno(aluno);
            alunosLista.appendChild(div);
        });
        alunosLista.style.display = "block";
    } else {
        alunosLista.style.display = "none";
    }
}

function preencherDadosAluno(aluno) {
    document.getElementById("nomeAluno").value = aluno.nome;
}

async function carregarOcorrenciasAPI() {
    try {
        const response = await fetch(`${API_BASE_URL}/index.php/api/ocorrencias`, {
            headers: { 'Authorization': 'Bearer ' + token }
        });
        if (!response.ok) {
            if (response.status === 401 || response.status === 403) {
                alert('Sessão expirada ou não autenticado. Por favor, faça login novamente.');
                logout();
                return;
            }
            throw new Error('Erro ao carregar ocorrências');
        }
        ocorrencias = await response.json();
        atualizarTabelaRegistro();
    } catch (err) {
        console.error(err);
        alert('Erro ao carregar ocorrências do servidor.');
    }
}

document.getElementById("formOcorrencia").addEventListener("submit", async function (e) {
    e.preventDefault();
    if (!token) {
        alert("Você precisa fazer login para registrar uma ocorrência.");
        return;
    }

    const ocorrencia = {
        aluno: document.getElementById("nomeAluno").value,
        turma: document.getElementById("turmaSelect").value,
        data: new Date().toLocaleDateString(),
        motivo: document.getElementById("motivo").value,
        nomePai: document.getElementById("nomepai").value,
        nomeMae: document.getElementById("nomeMae").value,
        estado: document.getElementById("Estado").value,
        cidade: document.getElementById("Cidade").value,
        cep: document.getElementById("CEP").value,
        bairro: document.getElementById("bairro").value,
        telefone: document.getElementById("telefone").value
    };

    try {
        const response = await fetch(`${API_BASE_URL}/index.php/api/ocorrencias`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            },
            body: JSON.stringify(ocorrencia)
        });
        if (!response.ok) {
            if (response.status === 401 || response.status === 403) {
                alert('Sessão expirada ou não autenticado. Por favor, faça login novamente.');
                logout();
                return;
            }
            const error = await response.json();
            throw new Error(error.message || 'Falha ao enviar a ocorrência');
        }

        await carregarOcorrenciasAPI();
        fecharFormulario();
    } catch (err) {
        console.error(err);
        alert('Erro ao enviar ocorrência: ' + err.message);
    }
});

function mostrarRegistro() {
    if (!token) {
        alert("Por favor, faça login para acessar o registro.");
        return;
    }
    document.getElementById("registro").style.display = "block";
    document.getElementById("paginaTurmas").style.display = "none";
    document.querySelector(".buttons").style.display = "none";
    carregarOcorrenciasAPI();
}

function voltarParaPaginaInicial() {
    document.getElementById("registro").style.display = "none";
    document.getElementById("paginaTurmas").style.display = "block";
    document.querySelector(".buttons").style.display = "flex";
}

function atualizarTabelaRegistro() {
    const tbody = document.querySelector("#tabelaRegistro tbody");
    tbody.innerHTML = "";

    ocorrencias.forEach(ocorrencia => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${ocorrencia.aluno}</td>
            <td>${ocorrencia.turma}</td>
            <td>${ocorrencia.data}</td>
            <td title="Pai: ${ocorrencia.nomePai || ''}, Mãe: ${ocorrencia.nomeMae || ''}, Estado: ${ocorrencia.estado || ''}, Cidade: ${ocorrencia.cidade || ''}, CEP: ${ocorrencia.cep || ''}, Bairro: ${ocorrencia.bairro || ''}, Telefone: ${ocorrencia.telefone || ''}">
                ${ocorrencia.motivo}
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function filtrarRegistro() {
    const filtro = document.getElementById("filtro").value.toLowerCase();
    const tbody = document.querySelector("#tabelaRegistro tbody");
    const linhas = tbody.getElementsByTagName("tr");
    Array.from(linhas).forEach(linha => {
        const texto = linha.textContent.toLowerCase();
        linha.style.display = texto.includes(filtro) ? "" : "none";
    });
}

function logout() {
    clearToken();
    atualizarUIUsuarioLogado();
    voltarParaPaginaInicial();
}

btnLogin.onclick = () => {
    window.location.href = 'tela_de_login.html';
};

async function realizarLoginAPI(nome, senha) {
    try {
        const response = await fetch(`${API_BASE_URL}/index.php/api/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ nome, senha })
        });
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || "Erro no login");
        }
        const data = await response.json();
        saveToken(data.token);
        alert("Login realizado com sucesso!");
        window.location.href = 'index.html';
    } catch (error) {
        alert("Login falhou: " + error.message);
    }
}

window.realizarLoginAPI = realizarLoginAPI;
